const CONSTANTS = {
  INTERNAL_ERROR_CREATE_TOPIC:'Houve um erro ao criar tópico no pubsub',
  INTERNAL_ERROR_PUBLISH:'Houve um erro ao publicar no tópico no pubsub'
}

module.exports = Object.freeze(CONSTANTS)