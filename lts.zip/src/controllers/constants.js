const CONSTANTS = {
  ERROR_PUBLISH:'Houve um erro ao enviar uma mensagem para o papaléguas'
}

module.exports = Object.freeze(CONSTANTS)